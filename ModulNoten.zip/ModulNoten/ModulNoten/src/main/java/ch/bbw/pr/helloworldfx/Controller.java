package ch.bbw.pr.helloworldfx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;


/**
 *  Klasse Controller
 *  Der Controller nimmt die Daten aus der View,
 *   verarbeitet sie und schreibt sie ins Model.
 * @author Emanuel Constanti
 * @version 05.10.2020
 */


public class Controller {
	
	private Model myModel;
	
	@FXML
	private TextField modulTextField;
	
	
	@FXML
	private TextField gradeTextField;
	
	@FXML
	private ListView<String> modulesListView;
	
	public Controller() {
		super();
	}
	
	public void setModel(Model myModel) {
		this.myModel = myModel;
		//Binding 
		modulesListView.setItems(myModel.modulesProperty());
	}
	
	//Initialize die Controller Klasse
	@FXML 
	private void initialize() {
		
		modulTextField.setText("");
		gradeTextField.setText("");
	}
	
	@FXML
	private void addModulAndGrade(ActionEvent f) {
		myModel.add(modulTextField.getText(),Double.parseDouble(gradeTextField.getText()));
	}

}
