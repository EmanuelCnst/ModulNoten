package ch.bbw.pr.helloworldfx;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *  Model Klasse
 *  Das Model informiert die View, dass die
 *  View die Anzeige der Daten aktualisieren muss.
 * @author Emanuel Constanti
 *@version 05.10.2020
 */
public class Model {

	//Die Liste mit den Modul Noten 
	private ObservableList<String> modules;
	
	
	//Constructor 
	public Model() {
		this.modules = FXCollections.observableArrayList();
	}
		
	//Getter auf die ObservableList
	public ObservableList<String>modulesProperty(){
		return modules;
	}
	
	//So kan man eine neue Note hinzufügen Setter 
	public void add(String modul,double note) {
		String text = modul + " :" + note;
		modules.add(text);
	}
}
